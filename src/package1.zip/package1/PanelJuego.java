package package1;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Random;

public class PanelJuego extends JPanel {

    private JTextArea areaTexto;
    private JScrollPane scrollPane;

    private Random r = new Random();
    private int numRonda = 1;
    private String climaRonda;
    private String[] climas = { "NIEBLA", "LLUVIA", "CALOR", "NIEVE", "TERREMOTO" };
    private ArrayList<Equipo> participantes = new ArrayList<>();

    private PanelPrincipal panelPrincipal; // Para volver al panel principal después

    public PanelJuego(ArrayList<String> nombresEquipos, ArrayList<String> paisesSeleccionados) {
        setLayout(new BorderLayout());
        areaTexto = new JTextArea();
        areaTexto.setEditable(false);
        scrollPane = new JScrollPane(areaTexto);
        add(scrollPane, BorderLayout.CENTER);

        for (int i = 0; i < nombresEquipos.size(); i++) {
            Equipo equipo = new Equipo(nombresEquipos.get(i));
            Pais pais = new Pais(paisesSeleccionados.get(i));
            equipo.setPais(pais);
            participantes.add(equipo);
            repartirVidasIniciales(equipo);
        }

        jugar(nombresEquipos.size());
    }

    public void jugar(int numJugadores) {
        iniciarPartida(numJugadores);
        while (jugadoresVivos() >= 1) {
            climaRonda = establecerClimaRonda();
            ronda();
            numRonda++;
        }
        if (jugadoresVivos() == 1) {
            areaTexto.append("EL GANADOR ES: " + participantes.get(0).getNombre() + "\n");
        } else {
            areaTexto.append("EMPATE: Todos los jugadores han muerto\n");
        }

        // Volver al panel principal al terminar
        volverAlMenu();
    }

    private void iniciarPartida(int numJugadores) {
        for (int i = 0; i < numJugadores; i++) {
            String nombre = JOptionPane.showInputDialog(this, "Introduce el nombre del equipo " + (i + 1) + ":");
            Equipo equipo = new Equipo(nombre);
            Pais pais = new Pais(menuEscogerPais(equipo));
            equipo.setPais(pais);
            participantes.add(equipo);
            repartirVidasIniciales(equipo);
        }
    }

    private void repartirVidasIniciales(Equipo equipo) {
        switch (equipo.getPais().getNombrePais()) {
            case "FRANCIA": equipo.getPais().setVidasIniciales(260); break;
            case "DINAMARCA": equipo.getPais().setVidasIniciales(400); break;
            case "SUIZA": equipo.getPais().setVidasIniciales(100); break;
            default: equipo.getPais().setVidasIniciales(200);
        }
    }

    private void ronda() {
        areaTexto.append("\nRONDA " + numRonda + "\n");
        Utilities.imprimirValoresInicioRonda1(participantes, areaTexto);
        imprimirClima();
        climaTerremoto();
        resetAtacadosRonda();
        actualizarVidasInicioRonda();

        for (int i = 0; i < jugadoresVivos(); i++) {
            escudoItalia(participantes.get(i).getPais());
            repartirMisilesMAXAtaque(participantes.get(i));

            int opc;
            boolean seleccionadaAyuda = false;
            do {
                opc = menuAtacarDefender(participantes.get(i), numRonda, climaRonda, seleccionadaAyuda);
                if (opc == 1) {
                    atacar(participantes.get(i));
                } else if (opc == 2) {
                    misilesDefensa(participantes.get(i));
                } else {
                    seleccionadaAyuda = true;
                    ayudaAliada(participantes.get(i));
                }
            } while (opc == 3);
        }

        matarMuertos();
    }

    private void volverAlMenu() {
        SwingUtilities.invokeLater(() -> panelPrincipal.mostrar());
    }

    private String menuEscogerPais(Equipo equipo) {
        String[] opciones = {"FRANCIA", "DINAMARCA", "SUIZA", "ITALIA", "ALEMANIA", "AUSTRIA", "YUGOSLAVIA", "BÉLGICA"};
        String seleccion = (String) JOptionPane.showInputDialog(this, 
            "Selecciona un país para " + equipo.getNombre() + ":", 
            "Escoger País", 
            JOptionPane.QUESTION_MESSAGE, 
            null, 
            opciones, 
            opciones[0]);
        return seleccion;
    }

    private int menuAtacarDefender(Equipo equipo, int numRonda, String clima, boolean ayudaAliadaSeleccionada) {
        String[] opciones = {"Atacar", "Defender", "Pedir ayuda"};
        int seleccion = JOptionPane.showOptionDialog(this,
                equipo.getNombre() + ", elige una acción:",
                "Turno de " + equipo.getNombre(),
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                opciones,
                opciones[0]);
        return seleccion + 1; // Devuelve 1, 2 o 3
    }

    private int jugadoresVivos() {
        int aux = 0;
        for (int i = participantes.size() - 1; i >= 0; i--) {
            if (!participantes.get(i).isMuerte()) {
                aux++;
            } else {
                participantes.remove(i);
            }
        }
        return aux;
    }

    private void resetAtacadosRonda() {
        for (Equipo e : participantes) {
            e.setAtacadoEnRonda(false);
        }
    }

    private void actualizarVidasInicioRonda() {
        for (Equipo e : participantes) {
            e.setVidasInicioRonda(e.getPais().getVidasActuales());
        }
    }

    private void imprimirClima() {
        if (!climaRonda.equals("")) {
            areaTexto.append("El clima especial en la ronda " + numRonda + " es: " + climaRonda + "\n");
        } else {
            areaTexto.append("No hay clima especial en la ronda " + numRonda + "\n");
        }
    }

    private String establecerClimaRonda() {
        int aux = r.nextInt(8);
        if (aux < climas.length) {
            return climas[aux];
        } else {
            return "";
        }
    }

private void atacar(Equipo equipo) {
    repartirMisilesAtaque(equipo);
    while (equipo.getPais().getMisilesAtaque() > 0) {
        Utilities.imprimirValoresEntreAtaques1(equipo, areaTexto);
        Equipo objetivo = menuEscogerEquipoAtacar(equipo);
        objetivo.setAtacadoEnRonda(true);
        ataque(objetivo, menuCuantosMisilesAtacar(equipo), equipo);
        evaluarDefensa(objetivo);
    }
}

private void repartirMisilesMAXAtaque(Equipo equipo) {
    if (equipo.getPais().getNombrePais().equals("ALEMANIA")) {
        if (climaRonda.equals("NIEBLA"))
            equipo.getPais().setMisilesMaxAtaque(70);
        else
            equipo.getPais().setMisilesMaxAtaque(60);
    } else if (equipo.getPais().getNombrePais().equals("DINAMARCA") && numRonda <= 5) {
        equipo.getPais().setMisilesMaxAtaque(10 * numRonda);
    } else {
        equipo.getPais().setMisilesMaxAtaque(50);
    }
}

private void repartirMisilesAtaque(Equipo equipo) {
    int aux = menuNumeroMisilesAtaque(equipo);
    equipo.getPais().setMisilesAtaque(aux);
    if (climaRonda.equals("LLUVIA")) {
        equipo.getPais().setMisilesDefensa((equipo.getPais().getMisilesMaxAtaque() - aux) / 2 - 10);
    } else {
        equipo.getPais().setMisilesDefensa((equipo.getPais().getMisilesMaxAtaque() - aux) / 2);
    }
}

private void misilesDefensa(Equipo equipo) {
    if (equipo.getPais().getNombrePais().equals("AUSTRIA")) {
        if (climaRonda.equals("LLUVIA")) {
            equipo.getPais().setMisilesDefensa(equipo.getPais().getMisilesMaxAtaque() / 2 + 20);
        } else {
            equipo.getPais().setMisilesDefensa(equipo.getPais().getMisilesMaxAtaque() / 2 + 10);
        }
    } else {
        equipo.getPais().setMisilesDefensa(equipo.getPais().getMisilesMaxAtaque() / 2);
    }
    areaTexto.append(equipo.getNombre() + ", dispones de " + equipo.getPais().getMisilesDefensa() + " misiles de defensa.\n");
}

private void ataque(Equipo objetivo, int misiles, Equipo atacante) {
    switch (climaRonda) {
    case "NIEBLA":
        int aux = r.nextInt(100);
        if (aux <= 80) {
            evaluarAtaque(objetivo, misiles, atacante);
        } else {
            areaTexto.append("\nATAQUE FALLIDO POR NIEBLA\n");
            atacante.getPais().setMisilesAtaque(atacante.getPais().getMisilesAtaque() - misiles);
        }
        break;

    case "CALOR":
        misiles += 10;
        evaluarAtaque(objetivo, misiles, atacante);
        break;

    default:
        evaluarAtaque(objetivo, misiles, atacante);
    }
}

private void evaluarAtaque(Equipo objetivo, int misiles, Equipo atacante) {
    switch (objetivo.getPais().getNombrePais()) {
    case "SUIZA":
        int random = r.nextInt(100);
        if (random >= 40) {
            evaluarAtaqueAUX(objetivo, misiles, atacante);
        } else {
            atacante.getPais().setMisilesAtaque(atacante.getPais().getMisilesAtaque() - misiles);
            areaTexto.append("SUIZA ha evitado el ataque!\n");
        }
        break;

    case "YUGOSLAVIA":
        if (!climaRonda.equals("")) {
            misiles = (int)(misiles * 1.1);
            evaluarAtaqueAUX(objetivo, misiles, atacante);
        } else {
            evaluarAtaqueAUX(objetivo, misiles, atacante);
        }
        break;

    default:
        evaluarAtaqueAUX(objetivo, misiles, atacante);
    }

    switch (atacante.getPais().getNombrePais()) {
    case "FRANCIA":
        int rando = r.nextInt(100);
        if (rando >= 95) {
            evaluarAtaqueAUX(objetivo, misiles, atacante);
        } else {
            atacante.getPais().setMisilesAtaque(atacante.getPais().getMisilesAtaque() - misiles);
            areaTexto.append("Ataque fallido!\n");
        }
        break;

    case "YUGOSLAVIA":
        misiles = (int)(misiles * 1.2);
        evaluarAtaqueAUX(objetivo, misiles, atacante);
        break;

    default:
        evaluarAtaqueAUX(objetivo, misiles, atacante);
    }
}

private void evaluarAtaqueAUX(Equipo objetivo, int misiles, Equipo atacante) {
    objetivo.getPais().setVidasActuales(objetivo.getPais().getVidasActuales() - misiles);
    atacante.getPais().setMisilesAtaque(atacante.getPais().getMisilesAtaque() - misiles);
}

private void evaluarDefensa(Equipo equipo) {
    Pais pais = equipo.getPais();
    if ((pais.getVidasActuales() + pais.getMisilesDefensa()) > equipo.getVidasInicioRonda()) {
        pais.setVidasActuales(equipo.getVidasInicioRonda());
        pais.setMisilesDefensa(pais.getVidasActuales() + pais.getMisilesDefensa() - equipo.getVidasInicioRonda());
    } else {
        pais.setVidasActuales(pais.getVidasActuales() + pais.getMisilesDefensa());
        pais.setMisilesDefensa(0);
    }
}

private Equipo menuEscogerEquipoAtacar(Equipo atacante) {
    ArrayList<Equipo> posibles = new ArrayList<>();
    for (Equipo e : participantes) {
        if (!e.equals(atacante) && !e.isMuerte()) {
            posibles.add(e);
        }
    }
    String[] nombres = posibles.stream().map(Equipo::getNombre).toArray(String[]::new);
    String seleccion = (String) JOptionPane.showInputDialog(this,
            "¿A quién quieres atacar?",
            "Atacar",
            JOptionPane.QUESTION_MESSAGE,
            null,
            nombres,
            nombres[0]);
    for (Equipo e : posibles) {
        if (e.getNombre().equals(seleccion)) {
            return e;
        }
    }
    return posibles.get(0);
}

private int menuCuantosMisilesAtacar(Equipo equipo) {
    String input = JOptionPane.showInputDialog(this,
            "¿Cuántos misiles quieres usar? (máximo " + equipo.getPais().getMisilesAtaque() + ")");
    try {
        int cantidad = Integer.parseInt(input);
        return Math.min(Math.max(0, cantidad), equipo.getPais().getMisilesAtaque());
    } catch (Exception e) {
        return 0;
    }
}

private int menuNumeroMisilesAtaque(Equipo equipo) {
    String input = JOptionPane.showInputDialog(this,
            "¿Cuántos misiles quieres usar para atacar? (máximo " + equipo.getPais().getMisilesMaxAtaque() + ")");
    try {
        int cantidad = Integer.parseInt(input);
        return Math.min(Math.max(0, cantidad), equipo.getPais().getMisilesMaxAtaque());
    } catch (Exception e) {
        return 0;
    }
}

private void ayudaAliada(Equipo equipo) {
    int random = randomAyudaAliada();
    switch (random) {
    case 0:
        misilesAtaqueAA(equipo);
        break;
    case 1:
        misilesDefensaAA(equipo);
        break;
    default:
        traicionAliadaAA(equipo);
    }
}

private int randomAyudaAliada() {
    int aux = r.nextInt(1, 10);
    if (aux < 4) {
        return 0;
    } else if (aux >= 4 && aux < 8) {
        return 1;
    } else {
        return 2;
    }
}

private void misilesAtaqueAA(Equipo equipo) {
    equipo.getPais().setMisilesMaxAtaque(equipo.getPais().getMisilesMaxAtaque() + 25);
}

private void misilesDefensaAA(Equipo equipo) {
    equipo.getPais().setMisilesDefensa(equipo.getPais().getMisilesDefensa() + 30);
}

private void traicionAliadaAA(Equipo equipo) {
    equipo.getPais().setVidasActuales(equipo.getPais().getVidasActuales() - 10);
}

private void climaTerremoto() {
    if (climaRonda.equals("TERREMOTO")) {
        for (Equipo e : participantes) {
            e.getPais().setVidasActuales(e.getPais().getVidasActuales() - 5);
        }
        areaTexto.append("TERREMOTO! Todos los jugadores reciben 5 de daño.\n");
        Utilities.imprimirValoresInicioRonda1(participantes, areaTexto);
    }
}

private void matarMuertos() {
    for (Equipo e : participantes) {
        if (e.getPais().getVidasActuales() <= 0) {
            e.setMuerte(true);
            areaTexto.append(e.getNombre() + " ha muerto\n");
        }
    }
}

private void escudoItalia(Pais pais) {
    if (pais.getNombrePais().equals("ITALIA")) {
        for (int i = 1; i <= numRonda; i++) {
            if (i % 2 == 0) {
                pais.setEscudo(pais.getEscudo() + 5);
            }
        }
    }
}
}